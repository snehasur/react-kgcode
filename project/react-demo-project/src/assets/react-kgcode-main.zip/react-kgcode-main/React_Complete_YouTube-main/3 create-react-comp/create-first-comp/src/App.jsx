import {KgButton} from "./KgButton";
import Hello from "./Hello";
import Random from "./Random";

function App() {
  return <div>
    <h1>
      This is the best React course
    </h1>
    <br />
    <Hello />
    <Random></Random>
    <Random></Random>
    <Random></Random>
    <Random></Random>
    <Random></Random>
  </div>
}

export default App;